---
name: plan-down
description: Two-stage planning workflow using zen mcp's planner and consensus tools. First uses planner to decompose tasks and create initial plan, then immediately uses consensus to review, enrich, and finalize the plan. Produces a complete plan.md file. Use when user requests "制定计划", "生成plan.md", "使用planner规划", "帮我做任务分解", or similar planning tasks.
---

# Plan-Down - 双阶段智能规划生成器

## Overview

This skill provides a comprehensive two-stage planning workflow that combines task decomposition with multi-perspective evaluation to produce high-quality, well-thought-out plans.

**Stage 1 - Task Decomposition (planner):** Break down user's idea into structured, actionable tasks with milestones
**Stage 2 - Plan Evaluation (consensus):** Multi-model review to enrich, validate, and finalize the plan

The final output is a complete `plan.md` file ready for implementation.

**Technical Architecture:**
- **zen-mcp planner**: Interactive, sequential planning tool with revision and branching capabilities
- **zen-mcp consensus**: Multi-model consensus building through systematic analysis and structured debate
- **Main Claude Model**: Context gathering, workflow orchestration, plan.md generation
- **User**: Provides ideas/requirements, approves initial plan outline

**Two-Stage Workflow:**
```
User Idea → Main Claude (收集上下文) → planner (任务分解) → consensus (评审完善) → plan.md
     ↑                                         ↓                        ↓
     └────────── Outline Approval ────────────┘                        │
                                                                        │
     ┌──────────────────── Final Review ───────────────────────────────┘
     ↓
   Saved plan.md
```

**Division of Responsibilities:**

**Stage 1 (Planning via planner):**
- **planner tool**: Task breakdown, milestone definition, dependency mapping, initial planning structure
- **Main Claude**: Gather user requirements, invoke planner, present outline for approval

**Stage 2 (Evaluation via consensus):**
- **consensus tool**: Multi-model evaluation, plan enrichment, risk identification, feasibility validation
- **Main Claude**: Invoke consensus, synthesize feedback, generate final plan.md

## When to Use This Skill

Trigger this skill when the user requests:
- "帮我制定计划"
- "生成 plan.md"
- "使用 planner 进行任务规划"
- "帮我做任务分解"
- "制定实施方案"
- "规划项目"
- Any request for systematic planning and task breakdown

**Use Cases:**
- Feature development planning
- Project implementation roadmaps
- Refactoring strategies
- Migration plans
- Research initiatives
- Complex task breakdowns

## Workflow: Two-Stage Planning Process

### Phase 1: Idea Collection and Context Gathering

**Main Claude's Responsibilities:**

1. **Clarify Planning Objectives:**
   - What is the user trying to achieve?
   - What is the scope and timeline?
   - What are the constraints and dependencies?
   - What is the expected outcome?

2. **Gather Relevant Context:**

   **a) Read Global Standards (CRITICAL):**
   - **Global AGENTS.md**: `/home/vc/.claude/AGENTS.md` - 全局规则 (G1-G8)、阶段要求 (P1-P4)
   - **Global CLAUDE.md**: `/home/vc/.claude/CLAUDE.md` - 模型开发工作流、伦理、可复现性

   **b) Read Project-Specific Standards (if exist):**
   - **Project AGENTS.md**: `./AGENTS.md` (当前目录) - 项目特定规则和流程
   - **Project CLAUDE.md**: `./CLAUDE.md` (当前目录) - 项目特定模型开发规范

   **c) Read Project Documentation:**
   - PROJECTWIKI.md - 项目知识库（架构、API、设计决策）
   - README.md - 项目概述
   - plan.md (如果存在) - 现有计划
   - docs/adr/*.md - 架构决策记录

   **d) Identify Code Context:**
   - Related code files/modules
   - Technical constraints
   - Existing architecture decisions

   **Standards Priority (when conflicts):**
   1. Global AGENTS.md (最高优先级)
   2. Project AGENTS.md (项目覆盖全局)
   3. Global CLAUDE.md
   4. Project CLAUDE.md
   5. PROJECTWIKI.md

3. **Define Planning Scope:**
   ```
   目标：[明确要实现什么]
   范围：[包含什么，不包含什么]
   时间线：[预期完成时间]
   约束条件：[技术、资源、依赖等限制]
   规范遵循：[必须遵循的 AGENTS.md/CLAUDE.md 规则]
   成功标准：[如何判断完成]
   相关文件：[列出所有相关文件路径]
   ```

**Output:** Well-defined planning scope with all necessary context

### Phase 2: Task Decomposition via Planner (Stage 1)

**Main Claude's Action:**

Invoke planner tool to perform interactive task breakdown:

```
Tool: mcp__zen__planner
Parameters:
- step: "基于以下需求，进行任务分解和初步规划：

  目标：[from Phase 1]
  范围：[from Phase 1]
  约束：[from Phase 1]

  **必须遵循的规范（CRITICAL）：**
  [从 Global AGENTS.md 提取的关键规则，如 G1-G8]
  [从 Global CLAUDE.md 提取的核心原则]
  [从 Project AGENTS.md/CLAUDE.md 提取的项目特定规则]

  例如：
  - G1: 文档一等公民 - 代码变更必须同步更新 PROJECTWIKI.md 和 CHANGELOG.md
  - G2: 知识库策略 - 架构图使用 Mermaid，API 定义与代码一致
  - CLAUDE.md 原则二: 可复现性 - 必须创建模型卡片/运行记录

  请创建详细的任务分解计划，包括：
  1. 主要里程碑和阶段
  2. 每个阶段的具体任务
  3. 任务之间的依赖关系
  4. 预估工作量和时间
  5. 潜在风险和缓解措施
  6. 验收标准
  7. **遵循 AGENTS.md/CLAUDE.md 规范的具体措施**

  使用清晰的层级结构组织任务。"

- step_number: 1
- total_steps: 3 (初步估计：问题理解 → 初步规划 → 细化调整)
- next_step_required: true
- model: "gemini-2.5-pro" (或用户指定的模型)
- use_assistant_model: true (启用专家模型进行规划验证)
```

**What Happens (planner workflow execution):**
1. planner receives planning requirements
2. planner performs interactive, sequential planning:
   - **Step 1**: Describe the task, problem, and scope
   - **Step 2**: Break down into phases and milestones
   - **Step 3**: Define specific tasks for each phase
   - **Step 4**: Map dependencies and risks
   - **Step 5**: Estimate effort and timeline
   - Each step builds on previous steps incrementally
3. planner supports revision and branching if needed
4. Initial plan structure is returned

**planner's Specialized Capabilities:**
- Interactive, step-by-step planning
- Revision capabilities (can revise earlier steps)
- Branching support (explore alternative approaches)
- Incremental plan building with deep reflection
- Expert model validation (if use_assistant_model=true)

**Output:** Initial plan outline with task breakdown

**Main Claude's Action:**

Present initial plan outline to user for approval:

```
初步计划大纲已生成：

[显示任务分解结构]

主要里程碑：
1. [里程碑 1] - [预计时间]
2. [里程碑 2] - [预计时间]
3. [里程碑 3] - [预计时间]

任务总数：[N] 个
预估总时长：[X] 天/周

是否批准此初步计划？
- 是：继续评审和完善
- 否：请说明需要调整的部分
- 需要探索其他方案：将创建分支规划
```

**If user requests revision:**
- Use planner's revision capability (set `is_step_revision: true`)
- Or create alternative branch (set `is_branch_point: true`)

### Phase 3: Plan Evaluation via Consensus (Stage 2)

**Main Claude's Action (after outline approval):**

**STEP 1: Invoke consensus tool for multi-model evaluation**

**Model Support:**
- consensus directly calls all models via their configured API keys
- Supported models: codex, gemini-2.5-pro, gpt-5-pro, claude, etc.
- **No CLI launch required** - all models use direct API access
- Ensure API keys are properly configured in the environment

```
Tool: mcp__zen__consensus
Parameters:
- step: "请评审以下初步计划：

  [从 Phase 2 获得的初步计划]

  评审要点：
  1. 计划的完整性和可行性
  2. 任务分解的合理性
  3. 时间估算的准确性
  4. 风险识别是否充分
  5. 依赖关系是否清晰
  6. 验收标准是否明确
  7. 是否有遗漏的关键步骤
  8. 优化和改进建议

  提供具体、可操作的反馈。"

- step_number: 1
- total_steps: 4 (我的分析 + 3 个模型评审)
- next_step_required: true
- findings: "初步计划已通过 planner 生成，现进行多模型评审"
- models: [
    {model: "codex", stance: "against", stance_prompt: "批判性审查，挑战计划的可行性"},
    {model: "gemini-2.5-pro", stance: "neutral", stance_prompt: "客观评估，提供平衡的观点"},
    {model: "gpt-5-pro", stance: "for", stance_prompt: "优化建议，如何让计划更好"}
  ]
- use_assistant_model: true
```

**Important Notes:**
- consensus directly uses API keys configured in the environment
- All models (codex, gemini, gpt-5-pro, etc.) are called via direct API access
- No CLI launch or additional setup required
- Ensure all model API keys are properly configured before use

**What Happens (consensus workflow execution):**
1. consensus receives initial plan from planner
2. consensus orchestrates multi-model structured debate:
   - **Step 1**: Your (Main Claude's) independent analysis
   - **Step 2**: Model 1 (codex) - critical review stance
   - **Step 3**: Model 2 (gemini) - neutral evaluation stance
   - **Step 4**: Model 3 (gpt-5-pro) - optimization stance
   - **Final**: Synthesis of all perspectives
3. Each model provides feedback from their assigned stance
4. consensus synthesizes comprehensive recommendations
5. Enriched plan with multi-perspective insights is returned

**consensus's Specialized Capabilities:**
- Multi-model consultation (2+ models)
- Structured debate with configurable stances (for/against/neutral)
- Independent analysis by Main Claude first
- Comprehensive recommendation synthesis
- Expert validation after all models respond

**Output:** Enriched plan with multi-model feedback and recommendations

**Main Claude's Action:**

Synthesize consensus feedback and present to user:

```
多模型评审完成！

评审总结：
- 参与模型：3 个
- 发现的问题：[N] 个
- 优化建议：[M] 条

关键反馈：
[严重] Codex: [批判性意见]
[建议] Gemini: [中立评估]
[优化] GPT-5: [改进建议]

综合建议：
1. [综合建议 1]
2. [综合建议 2]
3. [综合建议 3]

我将根据这些反馈完善计划。是否继续？
```

### Phase 4: Final Plan Generation

**Main Claude's Action:**

Generate final plan.md incorporating all feedback:

1. **Integrate Feedback:**
   - Address critical issues identified by consensus
   - Incorporate optimization suggestions
   - Clarify ambiguous points
   - Add missing tasks or milestones

2. **Structure plan.md:**

```markdown
# Plan: [项目/任务名称]

## 目标 (Objective)
[明确的目标描述]

## 范围 (Scope)
### 包含 (In-Scope)
- [项目 1]
- [项目 2]

### 不包含 (Out-of-Scope)
- [非目标 1]
- [非目标 2]

## 规范遵循 (Standards Compliance)

### 全局规范 (Global Standards)
**来源**: `/home/vc/.claude/AGENTS.md`, `/home/vc/.claude/CLAUDE.md`

**关键规则**:
- **G1 - 文档一等公民**: 代码变更必须同步更新 PROJECTWIKI.md 和 CHANGELOG.md
- **G2 - 知识库策略**: 架构图使用 Mermaid，API 定义与代码一致
- **G4 - 一致性与质量**: 确保 API 和数据模型与代码实现一致
- **CLAUDE 原则二 - 可复现性**: 创建模型卡片/运行记录，包含环境、依赖、超参数
- **CLAUDE 原则三 - 基线优先**: 先简单模型，后复杂模型

### 项目规范 (Project-Specific Standards)
**来源**: `./AGENTS.md`, `./CLAUDE.md` (如果存在)

- [项目特定规则 1]
- [项目特定规则 2]

### 本计划遵循措施:
- [ ] 每个代码变更阶段包含文档更新任务
- [ ] 使用 Mermaid 绘制架构和流程图
- [ ] 创建模型卡片（如涉及机器学习）
- [ ] 遵循 Conventional Commits 规范
- [ ] [其他项目特定遵循措施]

## 里程碑 (Milestones)
1. [ ] **[里程碑 1]** - [预计完成时间]
   - [关键交付物]
2. [ ] **[里程碑 2]** - [预计完成时间]
   - [关键交付物]

## 任务分解 (Task Breakdown)

### 阶段 1: [阶段名称]
**目标**: [阶段目标]
**预计时长**: [X 天/周]

- [ ] **任务 1.1**: [任务描述]
  - 依赖: [无 / 任务 X.X]
  - 预计工作量: [X 小时/天]
  - 验收标准: [明确的完成标准]

- [ ] **任务 1.2**: [任务描述]
  - 依赖: 任务 1.1
  - 预计工作量: [X 小时/天]
  - 验收标准: [明确的完成标准]

### 阶段 2: [阶段名称]
...

## 依赖关系 (Dependencies)
```mermaid
graph TD
    A[任务 1.1] --> B[任务 1.2]
    B --> C[任务 2.1]
    C --> D[里程碑 1]
```

## 风险管理 (Risk Management)
| 风险 | 影响 | 概率 | 缓解措施 |
|------|------|------|---------|
| [风险 1] | 高/中/低 | 高/中/低 | [缓解措施] |
| [风险 2] | 高/中/低 | 高/中/低 | [缓解措施] |

## 资源需求 (Resource Requirements)
- **人力**: [所需角色和人数]
- **工具**: [所需工具和服务]
- **时间**: [总预计时间]

## 验收标准 (Acceptance Criteria)
- [ ] [标准 1]
- [ ] [标准 2]
- [ ] [标准 3]

## 评审历史 (Review History)
- **Planner 评审**: [日期] - 任务分解完成
- **Consensus 评审**: [日期] - 多模型验证通过
  - Codex: [关键反馈]
  - Gemini: [关键反馈]
  - GPT-5: [关键反馈]

## 修订记录 (Revision Log)
- [日期] - 初始计划创建
- [日期] - 根据 consensus 反馈更新
```

3. **Save to File:**
   - Use Write tool to save to `./plan.md`
   - Or user-specified path
   - Default filename: `plan.md`

**Output:** Complete plan.md file saved to disk

### Phase 5: Post-Planning Actions (Optional)

**Main Claude's Action (if requested by user):**

1. **Create Task Tracking:**
   - Extract tasks into GitHub Issues
   - Create project board
   - Set up milestones

2. **Generate Summary:**
   - One-page executive summary
   - Gantt chart (Mermaid)
   - Timeline visualization

3. **Integration with Project Wiki:**
   - Link plan.md to PROJECTWIKI.md
   - Update "设计决策 & 技术债务" section
   - Add to CHANGELOG.md

## Tool Parameters Reference

### mcp__zen__planner Tool

**Purpose:** Interactive, sequential planning with revision and branching capabilities

**Key Parameters:**

```yaml
step: |           # Planning content for this step
  [Step 1: Describe task, problem, scope]
  [Later steps: Updates, revisions, branches, questions]
step_number: 1    # Current step (starts at 1)
total_steps: 3    # Estimated total steps
next_step_required: true  # Whether another step follows
model: "gemini-2.5-pro"  # Model for planning
use_assistant_model: true  # Enable expert validation
is_step_revision: false    # Set true when replacing a previous step
revises_step_number: null  # Step number being replaced (if revising)
is_branch_point: false     # True when creating alternative branch
branch_id: null            # Branch name (e.g., "approach-A")
branch_from_step: null     # Step number where branch starts
more_steps_needed: false   # True when adding steps beyond prior estimate
```

**Specialized Capabilities:**
- Step-by-step incremental planning
- Revision support (replace earlier steps)
- Branching (explore multiple approaches)
- Deep reflection between steps
- Expert model validation
- Context preservation via continuation_id

**Typical Flow:**
```
Step 1: Describe task → planner analyzes
Step 2: Break down phases → planner structures
Step 3: Define tasks → planner details
Step 4: Map dependencies → planner validates
Final: Complete plan outline
```

### mcp__zen__consensus Tool

**Purpose:** Multi-model consensus building through systematic analysis and structured debate

**Key Parameters:**

```yaml
step: |           # The proposal/question every model will see
  [Evaluate the following plan...]
  [Provide specific, actionable feedback]
step_number: 1    # Current step (1 = your analysis, 2+ = model responses)
total_steps: 4    # Number of models + synthesis step
next_step_required: true  # True until synthesis
findings: |       # Step 1: your analysis; Steps 2+: summarize model response
  [Your independent analysis or model response summary]
models: [         # User-specified roster (2+ models, each with unique stance)
  {model: "codex", stance: "against", stance_prompt: "Critical review"},
  {model: "gemini-2.5-pro", stance: "neutral", stance_prompt: "Objective"},
  {model: "gpt-5-pro", stance: "for", stance_prompt: "Optimization"}
]
relevant_files: []  # Optional supporting files (absolute paths)
use_assistant_model: true  # Enable expert synthesis
current_model_index: 0      # Managed internally, starts at 0
model_responses: []         # Internal log of responses
```

**Model Support:**
- consensus directly calls all models via their configured API keys
- Supported models: codex, gemini-2.5-pro, gpt-5-pro, claude, etc.
- **No CLI launch required** - all models use direct API access
- Ensure all model API keys are properly configured in the environment

**Specialized Capabilities:**
- Multi-model consultation (minimum 2 models)
- Configurable stances (for/against/neutral)
- Independent Main Claude analysis first
- Systematic debate structure
- Comprehensive synthesis
- Expert validation after all models respond

**Stance Configuration:**
- **"against"**: Critical review, challenge feasibility, identify risks
- **"neutral"**: Objective evaluation, balanced perspective
- **"for"**: Optimization suggestions, improvement opportunities

**Typical Flow:**
```
Step 1: Your independent analysis (findings)
Step 2: Model 1 evaluation (codex - critical)
Step 3: Model 2 evaluation (gemini - neutral)
Step 4: Model 3 evaluation (gpt-5-pro - optimistic)
Final: Synthesis of all perspectives
```

### Typical Two-Stage Tool Flow

```
Phase 1: Main Claude gathers context
    ↓
Phase 2: planner → Task decomposition (incremental, 3-5 steps)
    ↓ [initial plan outline]
    User approval
    ↓
Phase 3: consensus → Multi-model evaluation (4-5 steps)
    ↓ [enriched plan with feedback]
Phase 4: Main Claude → Synthesize and generate plan.md
    ↓
Phase 5: Save plan.md to disk
```

## Best Practices

### For Effective Planning

1. **Clear Objectives:**
   - Start with well-defined goals
   - Clarify scope boundaries (in-scope vs out-of-scope)
   - Set realistic timelines
   - Define success criteria upfront

2. **Comprehensive Context:**
   - Gather all relevant project documentation
   - Understand existing architecture decisions
   - Identify technical constraints early
   - Note dependencies on external systems

3. **Iterative Refinement:**
   - Use planner's revision capability when needed
   - Don't hesitate to explore alternative branches
   - Incorporate consensus feedback thoroughly
   - Validate with domain experts if available

4. **Risk-Aware Planning:**
   - Identify risks early (planner stage)
   - Get multi-perspective risk assessment (consensus stage)
   - Define mitigation strategies
   - Plan for contingencies

### Plan Quality Standards

**Must Include:**
- Clear objective and scope definition
- Hierarchical task breakdown with dependencies
- Realistic time estimates
- Risk assessment and mitigation
- Acceptance criteria for each phase
- **Mermaid diagrams** for dependencies and timeline
- Review history showing planner + consensus validation

**Plan.md Structure:**
```
1. Objective (明确目标)
2. Scope (范围界定)
3. Standards Compliance (规范遵循) - 全局 + 项目规范 ✨
4. Milestones (里程碑)
5. Task Breakdown (任务分解) - 可勾选
6. Dependencies (依赖关系) - Mermaid 图
7. Risk Management (风险管理) - 表格
8. Resource Requirements (资源需求)
9. Acceptance Criteria (验收标准)
10. Review History (评审历史)
11. Revision Log (修订记录)
```

**Formatting Best Practices:**
- Use checkboxes `[ ]` for all tasks and milestones
- Group tasks by phases/stages
- Use Mermaid `graph TD` for dependency visualization
- Use tables for risk assessment
- Include time estimates for each task
- Add dependencies explicitly (task X.X depends on task Y.Y)

## Notes

- **Two-Stage Architecture**: planner for task breakdown → consensus for multi-model validation
- **Standards-Based Planning**: CRITICAL - All plans must comply with global and project-specific AGENTS.md/CLAUDE.md standards
- **Standards Priority Hierarchy**:
  1. Global AGENTS.md (`/home/vc/.claude/AGENTS.md`) - 最高优先级
  2. Project AGENTS.md (`./AGENTS.md`) - 项目覆盖全局
  3. Global CLAUDE.md (`/home/vc/.claude/CLAUDE.md`)
  4. Project CLAUDE.md (`./CLAUDE.md`)
  5. PROJECTWIKI.md - 项目特定文档
- **Sequential Workflow**: Each stage builds on the previous one
- **Iterative Refinement**: Both planner and consensus support revision and improvement
- **Multi-Perspective**: consensus ensures plan is evaluated from multiple angles (critical, neutral, optimistic)
- **Context Preservation**: Both tools support continuation_id for multi-turn workflows
- **Expert Validation**: Both tools can invoke expert models for additional validation
- **Output Format**: Final plan.md includes dedicated "Standards Compliance" section listing applicable rules
- **Compliance Verification**: planner ensures tasks include standards adherence; consensus validates compliance
- **Compatibility**: Works with AGENTS.md workflow (especially P2: 制定方案)
- **Flexibility**: Supports branching (alternative approaches) and revision (refine steps)
- **Quality Assurance**: Dual-stage validation (planner structures + consensus validates) ensures high-quality plans
- **Tool Separation**: planner = planning workflow, consensus = evaluation workflow - each has distinct responsibilities
